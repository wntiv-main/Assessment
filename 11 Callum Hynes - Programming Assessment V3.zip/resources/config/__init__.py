"""Module implimenting managers for config files."""

from resources.config.config import Config
from resources.config.botconfig import BotConfig
from resources.config.gamemodeconfig import GamemodeConfig
